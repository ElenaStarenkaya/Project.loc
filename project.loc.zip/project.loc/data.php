<?php

$posts = [
    ['title' => 'post one', 'slug one', 'img' => 'img/pic1.jpg'],
    ['title' => 'post two', 'slug two','img' => 'img/pic2.jpg'],
    ['title' => 'post new', 'slug new','img' => 'img/pic3.jpg'],
    ['title' => 'post last', 'slug last', 'img' => 'img/pic4.jpg']
];