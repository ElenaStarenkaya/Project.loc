<?php

include('./functions.php');

include('./data.php');

$posts_tmp = get_template('./templates/elements/post_list.php', ['posts' => $posts]);

$elements_tmp = [
    'header' => get_template('./templates/elements/header.php'),
    'posts' => $posts_tmp,
    'gallery' => get_template('./templates/elements/gallery.php'),
    'features' => get_template('./templates/elements/features.php'),
    'contact_form' => get_template('./templates/elements/contact_form.php'),
    'footer' => get_template('./templates/elements/footer.php'),
    'scripts' => get_template('./templates/elements/scripts.php')
];

$page_tmp = get_template('./templates/pages/home.php', $elements_tmp);

// $content = "Hello World!";

// $layout_tmp = get_template('./templates/layouts/main.php', ['page' => $content]);
$layout_tmp = get_template('./templates/layouts/main.php', ['page' => $page_tmp]);

echo $layout_tmp;