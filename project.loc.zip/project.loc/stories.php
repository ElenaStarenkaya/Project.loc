<?php

include ('./functions.php');
include('./data.php');

$posts_tmp = get_template('./templates/elements/post_list.php', ['posts' => $posts]);

$elements_tmp = [
    'header' => get_template('./templates/elements/header.php'),
    'posts' => $posts_tmp,    
    'footer' => get_template('./templates/elements/footer.php')
    ];


    $page_tmp = get_template('./templates/pages/posts.php', $elements_tmp);



    $layout_tmp = get_template('./templates/layouts/main.php', ['page' => $page_tmp]);

    echo $layout_tmp;

