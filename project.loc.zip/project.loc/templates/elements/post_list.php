<?php



foreach($posts as $key => $post) {
    if($key % 2 == 0){  
echo get_template('./templates/elements/post_card1.php', $post);
    }
    else {
        echo get_template('./templates/elements/post_card2.php', $post);
    }
}