<?php

echo $header;
echo $posts;
echo $footer;
